<?php

require 'header.php';

$data['subtitle'] = $lang['search'];
$data['content'] .= '<form action = "search.php" method = "post">
<h1>' .$data['subtitle']. '</h1>
<p><input name = "search"/> <input type = "submit"/></p>
</form>';
if(isset($_POST['search'][0]))
{
	$data['content'] .= '<ul>';
	$posts = listEntry('post/');
	foreach($posts as &$post)
	{
		$postEntry = readEntry('post', $post);
		if(strpos($postEntry['title'], $_POST['search']) !== false || strpos($postEntry['content'], $_POST['search']) !== false)
		{
			$data['content'] .= '<li>' .managePost($post). '<a href = "view.php?post=' .$post. '">' .$postEntry['title']. '</a></li>';
		}
	}
	$data['content'] .= '</ul>';
}

$template = 'main';
require 'footer.php';

?>
