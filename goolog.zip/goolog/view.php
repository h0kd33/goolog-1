<?php

require 'header.php';

if(isset($_GET['post']) && isValidEntry('post', $_GET['post']))
{
	require 'include/parser.inc.php';
	$postEntry = readEntry('post', $_GET['post']);
	
	$postEntry['view']++;
	saveEntry('post', $_GET['post'], $postEntry);
	
	$data['subtitle'] = $postEntry['title'];
	$data['content'] .= '<div class = "entryContainer">
	<div class = "entryHeader"><h1>' .managePost($_GET['post']).$data['subtitle']. '</h1></div>
	<div class = "entryMain">
	<p>' .content($postEntry['content']). '</p>
	<p><a class = "button" href = "add.php?comment=' .$_GET['post']. '">' .$lang['leaveReply']. '</a></p>
	</div>
	<div class = "entryFooter"><ul>';
	if(isset($postEntry['category']))
	{
		$categoryEntry = readEntry('category', $postEntry['category']);
		$data['content'] .= '<li><a href = "view.php?category=' .$postEntry['category']. '">' .$categoryEntry['name']. '</a></li>';
	}
	$data['content'] .= '<li>' .$lang['comment']. ' (' .count($postEntry['comment']). ')</li>
	<li>' .$lang['view']. ' (' .$postEntry['view']. ')</li>
	<li>' .date('Y-m-d H:i', strtotime($_GET['post'])). '</li>
	</ul></div>
	</div>';
	if($postEntry['comment'])
	{
		$data['content'] .= '<h3>' .$lang['comment']. ' (' .count($postEntry['comment']). ')</h3>';
		foreach($postEntry['comment'] as &$comment)
		{
			$commentEntry = readEntry('comment', $comment);
			$data['content'] .= '<div class = "entryContainer">
			<div class = "entryHeader">' .manageComment($comment).$commentEntry['author']. ' ' .$lang['said']. '...</div>
			<div class = "entryMain">
			<p>' .content($commentEntry['content']). '</p>
			</div>
			<div class = "entryFooter"><ul><li>' .date('Y-m-d H:i', strtotime($comment)). '</li></ul></div>
			</div>';
		}
	}
}
else if(isset($_GET['category']) && isValidEntry('category', $_GET['category']))
{
	$categoryEntry = readEntry('category', $_GET['category']);
	$data['subtitle'] = $categoryEntry['name'];
	$data['content'] .= '<h1>' .manageCategory($_GET['category']).$data['subtitle']. '</h1>
	<ul>';
	if($categoryEntry['post'])
	{
		foreach($categoryEntry['post'] as &$post)
		{
			$postEntry = readEntry('post', $post);
			$data['content'] .= '<li>' .managePost($post). '<a href = "view.php?post=' .$post. '">' .$postEntry['title']. '</a></li>';
		}
	}
	else
	{
		$data['content'] .= '<li>' .$lang['none']. '</li>';
	}
	$data['content'] .= '</ul>';
}
else if(isset($_GET['archive']) && isValidEntry('archive', $_GET['archive']))
{
	$posts = listEntry('post/' .$_GET['archive']);
	$data['subtitle'] = date('F Y', strtotime($_GET['archive']));
	$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
	<ul>';
	if($posts)
	{
		foreach($posts as &$post)
		{
			$postEntry = readEntry('post', $post);
			$data['content'] .= '<li>' .managePost($post). '<a href = "view.php?post=' .$post. '">' .$postEntry['title']. '</a></li>';
		}
	}
	else
	{
		$data['content'] .= '<li>' .$lang['none']. '</li>';
	}
	$data['content'] .= '</ul>';
}
else
{
	header('Location: index.php?post');
}

$template = 'main';
require 'footer.php';

?>
