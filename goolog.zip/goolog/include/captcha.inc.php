<?php

function showCaptcha()
{
	return date('j'). ' + ' .(date('N') + date('g')). ' = ? <input name = "bot"/>';
}

function checkCaptcha()
{
	return isset($_POST['bot'][0]) && $_POST['bot'] == date('j') + date('N') + date('g');
}

?>
