<?php

function managePost($post)
{
	return isset($_SESSION['admin'])? '<a href = "categorize.php?post=' .$post. '">[#]</a><a href = "edit.php?post=' .$post. '">[!]</a><a href = "delete.php?post=' .$post. '">[x]</a>' : '';
}

function manageComment($comment)
{
	return isset($_SESSION['admin'])? '<a href = "edit.php?comment=' .$comment. '">[!]</a><a href = "delete.php?comment=' .$comment. '">[x]</a>' : '';
}

function manageCategory($category)
{
	return isset($_SESSION['admin'])? '<a href = "edit.php?category=' .$category. '">[!]</a><a href = "delete.php?category=' .$category. '">[x]</a>' : '';
}

function manageLink($link)
{
	return isset($_SESSION['admin'])? '<a href = "edit.php?link=' .$link. '">[!]</a><a href = "delete.php?link=' .$link. '">[x]</a>' : '';
}

?>
