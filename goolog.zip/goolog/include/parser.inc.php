<?php

function bbcode(&$text)
{
	//the pattern to be matched
	//the replacement
	
	$pattern[] = '#\[b\](.*?)\[/b\]#i';
	$replace[] = '<b>$1</b>';
	
	$pattern[] = '#\[i\](.*?)\[/i\]#i';
	$replace[] = '<i>$1</i>';
	
	$pattern[] = '#\[u\](.*?)\[/u\]#i';
	$replace[] = '<u>$1</u>';
	
	$pattern[] = '#\[s\](.*?)\[/s\]#i';
	$replace[] = '<del>$1</del>';
	
	$pattern[] = '#\[img\](.*?)\[/img\]#i';
	$replace[] = '<img src = "$1" alt = ""/>';
	
	$pattern[] = '#\[url\](.*?)\[/url\]#i';
	$replace[] = '<a href = "$1">$1</a>';
	
	$pattern[] = '#\[youtube\]http://www.youtube.com/watch\?v=(.*?)\[/youtube\]#i';
	$replace[] = '<iframe width = "480" height = "390" src = "http://www.youtube.com/embed/$1?rel=0" frameborder = "0"></iframe>';
	//the variable for the replace
	return preg_replace($pattern, $replace, $text);
}

function summary(&$text)
{
	$text = explode(PHP_EOL, $text, 2);
	return bbcode($text[0]);
}

function content(&$text)
{
	return nl2br(bbcode($text));
}

?>
