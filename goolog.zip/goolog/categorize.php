<?php

require 'header.php';

if(isset($_GET['post'], $_SESSION['admin']) && isValidEntry('post', $_GET['post']))
{
	$postEntry = readEntry('post', $_GET['post']);
	if(isset($_POST['category']))
	{
		if(isset($postEntry['category']))
		{
			$categoryEntry = readEntry('category', $postEntry['category']);
			unset($categoryEntry['post'][$_GET['post']]);
			saveEntry('category', $postEntry['category'], $categoryEntry);
			
			unset($postEntry['category']);
		}
		if(isValidEntry('category', $_POST['category']))
		{
			$postEntry['category'] = $_POST['category'];
			
			$categoryEntry = readEntry('category', $postEntry['category']);
			$categoryEntry['post'][$_GET['post']] = $_GET['post'];
			saveEntry('category', $postEntry['category'], $categoryEntry);
		}
		saveEntry('post', $_GET['post'], $postEntry);
		$data['subtitle'] = $lang['post'].$lang['categorized'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "view.php?post=' .$_GET['post']. '">← ' .$lang['redirect']. '：' .$postEntry['title']. '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['categorize'].$lang['post']. '：' .$postEntry['title'];
		$data['content'] .= '<form action = "categorize.php?post=' .$_GET['post']. '" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['category']. ' <select name = "category">
		<option>Uncategorized</option>';
		$categories = listEntry('category/');
		foreach($categories as &$category)
		{
			$categoryEntry = readEntry('category', $category);
			$data['content'] .= '<option value = "' .$category. '">' .$categoryEntry['name']. '</option>';
		}
		$data['content'] .= '</select></p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else
{
	header('Location: index.php?post');
}

$template = 'main';
require 'footer.php';

?>
