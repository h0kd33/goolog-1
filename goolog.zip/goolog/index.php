<?php

require 'header.php';
require 'include/parser.inc.php';

//run goolog

if(isset($_GET['post']))
{
	$data['subtitle'] = $lang['post'];
	$data['content'] .= '<h1>' .(isset($_SESSION['admin'])? '<a href = "add.php?post">[+]</a>' : '').$data['subtitle']. '</h1>';
	$page = array_chunk(array_reverse(listEntry('post/')), 4);
	if(!isset($page[$_GET['post']-1]))
	{
		$_GET['post']=1;
	}
	if($page)
	{
		foreach($page[$_GET['post']-1] as &$post)
		{
			$postEntry = readEntry('post', $post);
			$data['content'] .= '<div class = "entryContainer">
			<div class = "entryHeader"><h3>' .managePost($post).$postEntry['title']. '</h3></div>
			<div class = "entryMain">
			<p>' .summary($postEntry['content']). '</p>
			<p><a class = "button" href = "view.php?post=' .$post. '">' .$lang['readMore']. '</a></p>
			</div>
			<div class = "entryFooter"><ul>';
			if(isset($postEntry['category']))
			{
				$categoryEntry = readEntry('category', $postEntry['category']);
				$data['content'] .= '<li><a href = "view.php?category=' .$postEntry['category']. '">' .$categoryEntry['name']. '</a></li>';
			}
			$data['content'] .= '<li>' .$lang['comment']. ' (' .count($postEntry['comment']). ')</li>
			<li>' .$lang['view']. ' (' .$postEntry['view']. ')</li>
			<li>' .date('Y-m-d H:i', strtotime($post)). '</li>
			</ul></div>
			</div>';
		}
	}
	else
	{
		$data['content'] .= '<p>' .$lang['none']. '</p>';
	}
	$data['content'] .= '<div id = "page"><ul>' .
	(isset($page[$_GET['post']-2])? '<li><a href = "index.php?post=' .($_GET['post']-1). '">← ' .$lang['prev']. '</a></li>' : '').
	'<li>' .$lang['page']. '：' .$_GET['post']. ' / ' .count($page). '</li>' .
	(isset($page[$_GET['post']])? '<li><a href = "index.php?post=' .($_GET['post']+1). '">' .$lang['next']. ' →</a></li>' : '').
	'</ul></div>';
}
else if(isset($_GET['comment']))
{
	$data['subtitle'] = $lang['comment'];
	$data['content'] .= '<h1>' .$data['subtitle']. '</h1>';
	$page = array_chunk(array_reverse(listEntry('comment/')), 4);
	if(!isset($page[$_GET['comment']-1]))
	{
		$_GET['comment']=1;
	}
	if($page)
	{
		foreach($page[$_GET['comment']-1] as &$comment)
		{
			$commentEntry = readEntry('comment', $comment);
			$postEntry = readEntry('post', $commentEntry['post']);
			$data['content'] .= '<div class = "entryContainer">
			<div class = "entryHeader">' .manageComment($comment).$lang['comment']. '：' .$postEntry['title']. '</div>
			<div class = "entryMain">
			<p>' .summary($commentEntry['content']). '</p>
			<p><a class = "button" href = "view.php?post=' .$commentEntry['post']. '">' .$lang['readMore']. '</a></p>
			</div>
			<div class = "entryFooter"><ul><li>' .date('Y-m-d H:i', strtotime($comment)). '</li></ul></div>
			</div>';

		}
	}
	else
	{
		$data['content'] .= '<p>' .$lang['none']. '</p>';
	}
	$data['content'] .= '<div id = "page"><ul>' .
	(isset($page[$_GET['comment']-2])? '<li><a href = "index.php?comment=' .($_GET['comment']-1). '">? ' .$lang['prev']. '</a></li>' : '').
	'<li>' .$lang['page']. '：' .$_GET['comment']. ' / ' .count($page). '</li>' .
	(isset($page[$_GET['comment']])? '<li><a href = "index.php?comment=' .($_GET['comment']+1). '">' .$lang['next']. ' ?</a></li>' : '').
	'</ul></div>';
}
else if(isset($_GET['more']))
{
	$data['subtitle'] = $lang['more'];

	//link
	$data['content'] .= '<h1>' .(isset($_SESSION['admin'])? '<a href = "add.php?link">[+]</a>' : '').$lang['link']. '</h1>
	<ul>';
	$links = listEntry('link/');
	if($links)
	{
		foreach($links as &$link)
		{
			$linkEntry = readEntry('link', $link);
			$data['content'] .= '<li>' .manageLink($link). '<a href = "' .$linkEntry['url']. '">' .$linkEntry['name']. '</a></li>';
		}
	}
	else
	{
		$data['content'] .= '<li>' .$lang['none']. '</li>';
	}
	$data['content'] .= '</ul>';
	
	//category
	$data['content'] .= '<h1>' .(isset($_SESSION['admin'])? '<a href = "add.php?category">[+]</a>' : '').$lang['category']. '</h1>
	<ul>';
	$categories = listEntry('category/');
	if($categories)
	{
		foreach($categories as &$category)
		{
			$categoryEntry = readEntry('category', $category);
			$data['content'] .= '<li>' .manageCategory($category). '<a href = "view.php?category=' .$category. '">' .$categoryEntry['name']. ' (' .count($categoryEntry['post']). ')</a></li>';
		}
	}
	else
	{
		$data['content'] .= '<li>' .$lang['none']. '</li>';
	}
	$data['content'] .= '</ul>';
	
	//archive
	$archives = listEntry('archive/');
	if($archives)
	{
		$data['content'] .= '<h1>' .$lang['archive']. '</h1>
		<ul>';
		foreach($archives as &$archive)
		{
			$data['content'] .= '<li><a href = "view.php?archive=' .$archive. '">' .date('F Y', strtotime($archive)). ' (' .count(listEntry('post/' .$archive)). ')</a></li>';
		}
		$data['content'] .= '</ul>';
	}
}
else
{
	header('Location: index.php?post');
}

$template = 'main';
require 'footer.php';

?>
