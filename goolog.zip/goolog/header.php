<?php

session_start();

//load config
require 'include/flatfile.inc.php';
require 'include/manage.inc.php';

if(!isValidEntry('config', 'config'))
{
	header('Location: install.php');
	exit;
}

$data = readEntry('config', 'config');
$data['content'] = '';

require 'lang/' .$data['lang']. '.lng.php';

// remove $_POST slash

if(isset($_POST) && get_magic_quotes_gpc())
{
	$_POST = array_map('stripslashes', $_POST);
}

?>
