<?php

require 'header.php';

if(isset($_GET['post'], $_SESSION['admin']) && isValidEntry('post', $_GET['post']))
{
	$postEntry = readEntry('post', $_GET['post']);
	if(isset($_POST['title'][0], $_POST['content'][0]))
	{
		$postEntry['title'] = $_POST['title'];
		$postEntry['content'] = $_POST['content'];
		saveEntry('post', $_GET['post'], $postEntry);
		$data['subtitle'] = $lang['post'].$lang['saved'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "view.php?post=' .$_GET['post']. '">← ' .$lang['redirect']. '：' .htmlspecialchars($_POST['title']). '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['edit'].$lang['post'];
		$data['content'] .= '<form action = "edit.php?post=' .$_GET['post']. '" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['title']. ' <input name = "title" value = "' .$postEntry['title']. '"/></p>
		<p>' .$lang['content']. '</p>
		<p>[b] [i] [u] [s] [img] [url] [youtube]</p>
		<p><textarea name = "content" cols = "80" rows = "10">' .$postEntry['content']. '</textarea></p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else if(isset($_GET['comment'], $_SESSION['admin']) && isValidEntry('comment', $_GET['comment']))
{
	$commentEntry = readEntry('comment', $_GET['comment']);
	if(isset($_POST['content'][0]))
	{
		$commentEntry['content'] = $_POST['content'];
		saveEntry('comment', $_GET['comment'], $commentEntry);
		$postEntry = readEntry('post', $commentEntry['post']);
		$data['subtitle'] = $lang['comment'].$lang['saved'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "view.php?post=' .$commentEntry['post']. '">← ' .$lang['redirect']. '：' .$postEntry['title']. '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['edit'].$lang['comment'];
		$data['content'] .= '<form action = "edit.php?comment=' .$_GET['comment']. '" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['content']. '</p>
		<p>[b] [i] [u] [s] [img] [url] [youtube]</p>
		<p><textarea name = "content" cols = "80" rows = "10">' .$commentEntry['content']. '</textarea></p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else if(isset($_GET['link'], $_SESSION['admin']) && isValidEntry('link', $_GET['link']))
{
	$linkEntry = readEntry('link', $_GET['link']);
	if(isset($_POST['name'][0], $_POST['url'][0]))
	{
		$linkEntry['name'] = $_POST['name'];
		$linkEntry['url'] = $_POST['url'];
		saveEntry('link', $_GET['link'], $linkEntry);
		$data['subtitle'] = $lang['link'].$lang['saved'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "index.php?more">← ' .$lang['redirect']. '：' .$lang['more']. '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['edit'].$lang['link'];
		$data['content'] .= '<form action = "edit.php?link=' .$_GET['link']. '" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['name']. ' <input name = "name" value = "' .$linkEntry['name']. '"/></p>
		<p>' .$lang['url']. ' <input name = "url" value = "' .$linkEntry['url']. '"/></p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else if(isset($_GET['category'], $_SESSION['admin']) && isValidEntry('category', $_GET['category']))
{
	$categoryEntry = readEntry('category', $_GET['category']);
	if(isset($_POST['name'][0]))
	{
		$categoryEntry['name'] = $_POST['name'];
		saveEntry('category', $_GET['category'], $categoryEntry);
		$data['subtitle'] = $lang['category'].$lang['saved'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "index.php?more">← ' .$lang['redirect']. '：' .$lang['more']. '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['edit'].$lang['category'];
		$data['content'] .= '<form action = "edit.php?category=' .$_GET['category']. '" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['name']. ' <input name = "name" value = "' .$categoryEntry['name']. '"/></p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else
{
	header('Location: index.php?post');
}

$template = 'main';
require 'footer.php';

?>
