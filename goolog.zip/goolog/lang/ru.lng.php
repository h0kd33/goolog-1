<?php

$lang['post'] = ' Заметки';
$lang['comment'] = ' Комментарии';
$lang['more'] = ' Разделы';
$lang['config'] = ' Конфигуратор';
$lang['logout'] = ' Выйти';
$lang['loggedOut'] = ' Вышел';
$lang['login'] = ' Войти';
$lang['loggedIn'] = ' Вошел';
$lang['redirect'] = ' Вернуться к записи';
$lang['leaveReply'] = ' Оставить комментарий';
$lang['said'] = ' сказал';
$lang['saved'] = ' сохранено';
$lang['add'] = ' Добавить ';
$lang['edit'] = ' Редактировать ';
$lang['title'] = ' Заголовок';
$lang['content'] = ' Содержание';
$lang['deleted'] = ' Удалить';
$lang['name'] = ' Имя';
$lang['view'] = ' Просмотров';
$lang['readMore'] = ' Дальше';
$lang['search'] = ' Поиск';
$lang['link'] = ' Ссылки';
$lang['category'] = ' Категории';
$lang['archive'] = ' Архивы';
$lang['url'] = 'URL';
$lang['categorize'] = ' Просмотр категорий';
$lang['categorized'] = ' К категории';
$lang['page'] = ' Страница';
$lang['prev'] = ' Новая';
$lang['next'] = ' Старая';
$lang['password'] = ' Пароль';
$lang['poweredBy'] = ' Технологии';
$lang['feed'] = 'Feed';
$lang['theme'] = ' Тема';
$lang['language'] = ' Локаль';
$lang['blogName'] = ' Название блога';
$lang['none'] = ' Извините, но здесь ничего нет!';

?>
