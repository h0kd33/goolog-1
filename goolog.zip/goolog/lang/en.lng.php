<?php

$lang['post'] = 'Post';
$lang['comment'] = 'Comment';
$lang['more'] = 'More';
$lang['config'] = 'Config';
$lang['logout'] = 'Logout';
$lang['loggedOut'] = 'Logged out';
$lang['login'] = 'Login';
$lang['loggedIn'] = 'Logged in';
$lang['redirect'] = 'Go back to';
$lang['leaveReply'] = 'Leave a reply';
$lang['said'] = 'said';
$lang['saved'] = ' saved';
$lang['add'] = 'Add new ';
$lang['edit'] = 'Edit previous ';
$lang['title'] = 'Title';
$lang['content'] = 'Content';
$lang['deleted'] = ' deleted';
$lang['name'] = 'Name';
$lang['view'] = 'View';
$lang['readMore'] = 'Read more';
$lang['search'] = 'Search';
$lang['link'] = 'Link';
$lang['category'] = 'Category';
$lang['archive'] = 'Archive';
$lang['url'] = 'URL';
$lang['categorize'] = 'Categorize previous ';
$lang['categorized'] = ' categorized';
$lang['page'] = 'Page';
$lang['prev'] = 'Newer';
$lang['next'] = 'Older';
$lang['password'] = 'Password';
$lang['poweredBy'] = 'Powered by';
$lang['feed'] = 'Feed';
$lang['theme'] = 'Theme';
$lang['language'] = 'Language';
$lang['blogName'] = 'Blog name';
$lang['none'] = 'Sorry, there is no entry';

?>
