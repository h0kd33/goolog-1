<?php

require 'header.php';

if(isset($_GET['post'], $_SESSION['admin']) && isValidEntry('post', $_GET['post']))
{
	$postEntry = readEntry('post', $_GET['post']);
	deleteEntry('post', $_GET['post']);
	if(isset($postEntry['category']))
	{
		$categoryEntry = readEntry('category', $postEntry['category']);
		unset($categoryEntry['post'][$_GET['post']]);
		saveEntry('category', $postEntry['category'], $categoryEntry);
	}
	foreach($postEntry['comment'] as &$comment)
	{
		deleteEntry('comment', $comment);
	}
	$data['subtitle'] = $lang['post'].$lang['deleted'];
	$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
	<p><a href = "index.php?post">← ' .$lang['redirect']. '：' .$lang['post']. '</a></p>';
}
else if(isset($_GET['comment'], $_SESSION['admin']) && isValidEntry('comment', $_GET['comment']))
{
	$commentEntry = readEntry('comment', $_GET['comment']);
	deleteEntry('comment', $_GET['comment']);
	
	$postEntry = readEntry('post', $commentEntry['post']);
	unset($postEntry['comment'][$_GET['comment']]);
	saveEntry('post', $commentEntry['post'], $postEntry);
	
	$data['subtitle'] = $lang['comment'].$lang['deleted'];
	$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
	<p><a href = "view.php?post=' .$commentEntry['post']. '">← ' .$lang['redirect']. '：' .$postEntry['title']. '</a></p>';
}
else if(isset($_GET['link'], $_SESSION['admin']) && isValidEntry('link', $_GET['link']))
{
	deleteEntry('link', $_GET['link']);
	$data['subtitle'] = $lang['link'].$lang['deleted'];
	$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
	<p><a href = "index.php?more">← ' .$lang['redirect']. '：' .$lang['more']. '</a></p>';
}
else if(isset($_GET['category'], $_SESSION['admin']) && isValidEntry('category', $_GET['category']))
{
	$categoryEntry = readEntry('category', $_GET['category']);
	deleteEntry('category', $_GET['category']);
	$posts = $categoryEntry['post'];
	foreach($posts as &$post)
	{
		$postEntry = readEntry('post', $post);
		unset($postEntry['category']);
		saveEntry('post', $post, $postEntry);
	}
	$data['subtitle'] = $lang['category'].$lang['deleted'];
	$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
	<p><a href = "index.php?more">← ' .$lang['redirect']. '：' .$lang['more']. '</a></p>';
}
else
{
	header('Location: index.php?post');
}

$template = 'main';
require 'footer.php';

?>
