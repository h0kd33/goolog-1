<?php

require 'header.php';

if(isset($_GET['post'], $_SESSION['admin']))
{
	if(isset($_POST['title'][0], $_POST['content'][0]))
	{
		$postEntry['title'] = $_POST['title'];
		$postEntry['content'] = $_POST['content'];
		$postEntry['view'] = 0;
		$postEntry['comment'] = array();
		$archive = date('Y-m');
		$post = date('Y-m-dHis');
		saveEntry('post', $post, $postEntry);
		if(!isValidEntry('archive', $archive))
		{
			$archiveEntry = '';
			saveEntry('archive', $archive, $archiveEntry);
		}
		$data['subtitle'] = $lang['post'].$lang['saved'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "view.php?post=' .$post. '">← ' .$lang['redirect']. '：' .$postEntry['title']. '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['add'].$lang['post'];
		$data['content'] .= '<form action = "add.php?post" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['title']. ' <input name = "title"/></p>
		<p>' .$lang['content']. '</p>
		<p>[b] [i] [u] [s] [img] [url] [youtube]</p>
		<p><textarea name = "content" cols = "80" rows = "10"></textarea></p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else if(isset($_GET['comment']) && isValidEntry('post', $_GET['comment']))
{
	require 'include/captcha.inc.php';
	$postEntry = readEntry('post', $_GET['comment']);
	if(isset($_POST['author'][0], $_POST['content'][0]) && !isset($_POST['author'][10]) && checkCaptcha())
	{
		$commentEntry['author'] = $_POST['author'];
		$commentEntry['content'] = $_POST['content'];
		$commentEntry['post'] = $_GET['comment'];
		$comment = date('Y-m-dHis');
		saveEntry('comment', $comment, $commentEntry);

		$postEntry['comment'][$comment] = $comment;
		saveEntry('post', $_GET['comment'], $postEntry);
		$data['subtitle'] = $lang['comment'].$lang['saved'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "view.php?post=' .$_GET['comment']. '">← ' .$lang['redirect']. '：' .$postEntry['title']. '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['add'].$lang['comment']. '：' .$postEntry['title'];
		$data['content'] .= '<form action = "add.php?comment=' .$_GET['comment']. '" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['name']. ' <input name = "author"/></p>
		<p>' .$lang['content']. '</p>
		<p>[b] [i] [u] [s] [img] [url] [youtube]</p>
		<p><textarea name = "content" cols = "80" rows = "10"></textarea></p>
		<p>' .showCaptcha(). '</p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else if(isset($_GET['link'], $_SESSION['admin']))
{
	if(isset($_POST['name'][0], $_POST['url'][0]))
	{
		$linkEntry['name'] = $_POST['name'];
		$linkEntry['url'] = $_POST['url'];
		saveEntry('link', date('Y-m-dHis'), $linkEntry);
		$data['subtitle'] = $lang['link'].$lang['saved'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "index.php?more">← ' .$lang['redirect']. '：' .$lang['more']. '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['add'].$lang['link'];
		$data['content'] .= '<form action = "add.php?link" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['name']. ' <input name = "name"/></p>
		<p>' .$lang['url']. ' <input name = "url"/></p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else if(isset($_GET['category'], $_SESSION['admin']))
{
	if(isset($_POST['name'][0]))
	{
		$categoryEntry['name'] = $_POST['name'];
		$categoryEntry['post'] = array();
		saveEntry('category', date('Y-m-dHis'), $categoryEntry);
		$data['subtitle'] = $lang['category'].$lang['saved'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "index.php?more">← ' .$lang['redirect']. '：' .$lang['more']. '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['add'].$lang['category'];
		$data['content'] .= '<form action = "add.php?category" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['name']. ' <input name = "name"/></p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else
{
	header('Location: index.php?post');
}

$template = 'main';
require 'footer.php';

?>
