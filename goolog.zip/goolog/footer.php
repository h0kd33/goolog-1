<?php

require 'template/' .$template. '.tpl.php';

?>
