<?php

session_start();

//add db if it does not exist
require 'include/flatfile.inc.php';

if(!isValidEntry('config', 'config'))
{
	mkdir('data');
	mkdir('data/post');
	mkdir('data/comment');
	mkdir('data/link');
	mkdir('data/category');
	mkdir('data/archive');
	mkdir('data/config');

	$config['password'] = 'demo';
	$config['title'] = 'goolog demo';
	$config['theme'] = 'classic';
	$config['lang'] = 'en';
	saveEntry('config', 'config', $config);
	$_SESSION['admin'] = true;
}

header('Location: index.php?post');

?>
