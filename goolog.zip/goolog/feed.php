<?php

require 'header.php';
require 'include/parser.inc.php';

$dir = dirname($_SERVER['SCRIPT_NAME']);
$data['url'] = 'http://' .$_SERVER['SERVER_NAME'].$dir.($dir !== '/'? '/' : '');

if(isset($_GET['post']))
{
	$data['subtitle'] = $lang['post'];
	$page = array_chunk(array_reverse(listEntry('post/')), 4);
	if($page)
	{
		foreach($page[0] as &$post)
		{
			$postEntry = readEntry('post', $post);
			$data['content'] .= '<entry>
			<id>' .$data['url']. 'view.php?post=' .$post. '</id>
			<title>' .$postEntry['title']. '</title>
			<updated>' .date('c', strtotime($post)). '</updated>
			<link href = "' .$data['url']. 'view.php?post=' .$post. '"/>
			<summary type = "html">' .htmlspecialchars(summary($postEntry['content'])). '</summary>
			</entry>';
		}
	}
}
else if(isset($_GET['comment']))
{
	$data['subtitle'] = $lang['comment'];
	$page = array_chunk(array_reverse(listEntry('comment/')), 4);
	if($page)
	{
		foreach($page[0] as &$comment)
		{
			$commentEntry = readEntry('comment', $comment);
			$postEntry = readEntry('post', $commentEntry['post']);
			$data['content'] .= '<entry>
			<id>' .$data['url']. 'view.php?post=' .$commentEntry['post']. '</id>
			<title>' .$lang['comment']. '：' .$postEntry['title']. '</title>
			<updated>' .date('c', strtotime($comment)). '</updated>
			<link href = "' .$data['url']. 'view.php?post=' .$commentEntry['post']. '"/>
			<summary type = "html">' .htmlspecialchars(summary($commentEntry['content'])). '</summary>
			</entry>';
		}
	}
}
else
{
	header('Location: feed.php?post');
}

$template = 'feed';
require 'footer.php';

?>
