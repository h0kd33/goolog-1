<?php

require 'header.php';

if(isset($_SESSION['admin']))
{
	if(isset($_POST['password'][0], $_POST['title'][0], $_POST['theme'], $_POST['lang']))
	{
		$config['password'] = $_POST['password'];
		$config['title'] = $_POST['title'];
		$config['theme'] = $_POST['theme'];
		$config['lang'] = $_POST['lang'];
		saveEntry('config', 'config', $config);
		$data['subtitle'] = $lang['config'].$lang['saved'];
		$data['content'] .= '<h1>' .$data['subtitle']. '</h1>
		<p><a href = "index.php?post">← ' .$lang['redirect']. '：' .$lang['post']. '</a></p>';
	}
	else
	{
		$data['subtitle'] = $lang['config'];
		$data['content'] .= '<form action = "config.php" method = "post">
		<h1>' .$data['subtitle']. '</h1>
		<p>' .$lang['password']. ' <input type = "password" name = "password" value = "' .$data['password']. '"/></p>
		<p>' .$lang['blogName']. ' <input name = "title" value = "' .$data['title']. '"/></p>
		<p>' .$lang['theme']. ' <select name = "theme">';
		$themes = fglob('theme/*.thm.css');
		foreach($themes as &$theme)
		{
			$value = basename($theme, '.thm.css');
			$data['content'] .= '<option value = "' .$value. '">' .$value. '</option>';
		}
		$data['content'] .= '</select></p>
		<p>' .$lang['language']. ' <select name = "lang">';
		$languages = fglob('lang/*.lng.php');
		foreach($languages as &$language)
		{
			$value = basename($language, '.lng.php');
			$data['content'] .= '<option value = "' .$value. '">' .$value. '</option>';
		}
		$data['content'] .= '</select></p>
		<p><input type = "submit"/></p>
		</form>';
	}
}
else
{
	header('Location: index.php?post');
}

$template = 'main';
require 'footer.php';

?>
