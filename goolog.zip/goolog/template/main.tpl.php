<?php header('Content-Type: text/html; charset=UTF-8');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns = "http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv = "content-type" content = "text/html;charset = UTF-8"/>
<meta name = "description" content = "<?php echo $data['subtitle'];?>"/>
<title><?php echo $data['subtitle'];?> - <?php echo $data['title'];?></title>
<link rel = "stylesheet" type = "text/css" href = "theme/<?php echo $data['theme'];?>.thm.css"/>
<link rel = "alternate" type = "application/atom+xml" href = "feed.php?post" title = "<?php echo $lang['feed'];?> (<?php echo $lang['post'];?>)"/>
<link rel = "alternate" type = "application/atom+xml" href = "feed.php?comment" title = "<?php echo $lang['feed'];?> (<?php echo $lang['comment'];?>)"/>
</head>
<body>
<div id = "container">
<div id = "header"><h2><?php echo $data['title'];?></h2></div>
<div id = "menu"><ul>
<li><a href = "index.php?post"><?php echo $lang['post'];?></a></li>
<li><a href = "index.php?comment"><?php echo $lang['comment'];?></a></li>
<li><a href = "search.php"><?php echo $lang['search'];?></a></li>
<li><a href = "index.php?more"><?php echo $lang['more'];?></a></li>
<?php echo isset($_SESSION['admin'])?
'<li><a href = "config.php">' .$lang['config']. '</a></li>
<li><a href = "auth.php?logout">' .$lang['logout']. '</a></li>' : 
'<li><a href = "auth.php?login">' .$lang['login']. '</a></li>';?>
</ul></div>
<div id = "main">
<?php echo $data['content'];?>
</div>
<div id = "footer"><ul>
<li><?php echo $lang['poweredBy'];?> <a href = "http://github.com/taylorchu/goolog">Goolog</a></li>
<li><a href = "feed.php?post"><?php echo $lang['feed'];?> (<?php echo $lang['post'];?>)</a></li>
<li><a href = "feed.php?comment"><?php echo $lang['feed'];?> (<?php echo $lang['comment'];?>)</a></li>
</ul></div>
</div>
</body>
</html>
